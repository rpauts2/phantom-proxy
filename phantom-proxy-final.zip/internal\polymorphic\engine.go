package polymorphic

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"math/big"
	"regexp"
	"strings"
	"sync"
	"time"
)

// Engine полиморфный JS движок
type Engine struct {
	mu            sync.Mutex
	level         string // low, medium, high
	seedRotation  int
	currentSeed   int64
	rng           *rand.Rand
	mutationCount int64
}

// MutationResult результат мутации
type MutationResult struct {
	OriginalHash string   `json:"original_hash"`
	MutatedCode  string   `json:"mutated_code"`
	Mutations    []string `json:"mutations"`
	Seed         int64    `json:"seed"`
}

// NewEngine создаёт новый полиморфный движок
func NewEngine(level string, seedRotation int) *Engine {
	if level == "" {
		level = "high"
	}
	if seedRotation == 0 {
		seedRotation = 15
	}
	
	return &Engine{
		level:        level,
		seedRotation: seedRotation,
		currentSeed:  time.Now().UnixNano(),
	}
}

// Mutate применяет мутации к JavaScript коду
func (e *Engine) Mutate(code string) *MutationResult {
	e.mu.Lock()
	defer e.mu.Unlock()
	
	e.rotateSeed()
	
	result := &MutationResult{
		OriginalHash: e.hash(code),
		MutatedCode:  code,
		Mutations:    make([]string, 0),
		Seed:         e.currentSeed,
	}
	
	// Мутация 1: Переименование переменных (medium, high)
	if e.level != "low" {
		result.MutatedCode = e.renameVariables(result.MutatedCode)
		result.Mutations = append(result.Mutations, "variable_renaming")
	}
	
	// Мутация 2: Трансформация строк (все уровни)
	result.MutatedCode = e.transformStrings(result.MutatedCode)
	result.Mutations = append(result.Mutations, "string_transformation")
	
	// Мутация 3: Base64 мутация (все уровни)
	result.MutatedCode = e.mutateBase64(result.MutatedCode)
	result.Mutations = append(result.Mutations, "base64_mutation")
	
	// Мутация 4: Мёртвый код (high)
	if e.level == "high" {
		result.MutatedCode = e.addDeadCode(result.MutatedCode)
		result.Mutations = append(result.Mutations, "dead_code_injection")
	}
	
	// Мутация 5: Изменение порядка операций (high)
	if e.level == "high" {
		result.MutatedCode = e.reorderOperations(result.MutatedCode)
		result.Mutations = append(result.Mutations, "operation_reordering")
	}
	
	e.mutationCount++
	
	return result
}

// renameVariables переименовывает переменные
func (e *Engine) renameVariables(code string) string {
	// Поиск объявлений переменных: var xxx = ..., let xxx = ..., const xxx = ...
	varRegex := regexp.MustCompile(`(var|let|const)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*=`)
	
	varMap := make(map[string]string)
	
	return varRegex.ReplaceAllStringFunc(code, func(match string) string {
		parts := varRegex.FindStringSubmatch(match)
		if len(parts) < 3 {
			return match
		}
		
		keyword := parts[1]  // var, let, const
		oldName := parts[2]
		
		// Генерация нового имени
		if _, exists := varMap[oldName]; !exists {
			varMap[oldName] = e.generateRandomName()
		}
		newName := varMap[oldName]
		
		// Замена в объявлении
		result := strings.Replace(match, oldName, newName, 1)
		
		// Замена всех остальных вхождений
		result = strings.ReplaceAll(result, oldName, newName)
		
		return result
	})
}

// generateRandomName генерирует случайное имя переменной
func (e *Engine) generateRandomName() string {
	prefixes := []string{"_0x", "_var", "_tmp", "_ctx", "_obj"}
	chars := "abcdef0123456789"
	
	prefix := prefixes[e.randomInt(0, len(prefixes))]
	name := prefix
	
	for i := 0; i < 8; i++ {
		name += string(chars[e.randomInt(0, len(chars))])
	}
	
	return name
}

// transformStrings трансформирует строковые литералы
func (e *Engine) transformStrings(code string) string {
	// Замена строковых литералов: "hello" -> String.fromCharCode(104, 101, 108, 108, 111)
	stringRegex := regexp.MustCompile(`"([^"\\]*(\\.[^"\\]*)*)"`)
	
	return stringRegex.ReplaceAllStringFunc(code, func(s string) string {
		// 50% шанс трансформации для полиморфизма
		if e.randomBool() {
			// Убираем кавычки и преобразуем
			content := s[1:len(s)-1]
			return e.toFromCharCode(content)
		}
		return s
	})
}

// toFromCharCode преобразует строку в fromCharCode
func (e *Engine) toFromCharCode(s string) string {
	var codes []string
	for _, c := range s {
		codes = append(codes, fmt.Sprintf("%d", c))
	}
	return fmt.Sprintf("String.fromCharCode(%s)", strings.Join(codes, ","))
}

// mutateBase64 изменяет способы генерации base64
func (e *Engine) mutateBase64(code string) string {
	// Замена: btoa(str) -> альтернативные реализации
	btoaRegex := regexp.MustCompile(`btoa\(([^)]+)\)`)
	
	alternatives := []string{
		`Buffer.from($1).toString('base64')`,
		`window.btoa.call(null, $1)`,
		`Function("return btoa")()($1)`,
		`atob(String.fromCharCode.apply(null, $1.split('').map(c => c.charCodeAt(0))))`,
		`btoa.call(window, $1)`,
	}
	
	return btoaRegex.ReplaceAllString(code, e.randomChoice(alternatives))
}

// addDeadCode добавляет бесполезный код
func (e *Engine) addDeadCode(code string) string {
	deadCodes := []string{
		`void 0;`,
		`!function(){};`,
		`Math.random()>2&&0;`,
		`for(let i=0;i<0;i++);`,
		`undefined&&undefined;`,
		`!function(){return!1}();`,
		`0&&(function(){})(),`,
		`NaN<2&&0,`,
	}
	
	// Вставка в случайное место
	pos := e.randomInt(0, len(code))
	insertion := e.randomChoice(deadCodes)
	
	return code[:pos] + insertion + code[pos:]
}

// reorderOperations изменяет порядок операций (где возможно)
func (e *Engine) reorderOperations(code string) string {
	// Пример: a + b + c -> c + a + b (для коммутативных операций)
	// Это упрощённая реализация
	
	// Замена: obj.prop -> obj["prop"]
	propRegex := regexp.MustCompile(`\.([a-zA-Z_$][a-zA-Z0-9_$]*)`)
	
	return propRegex.ReplaceAllStringFunc(code, func(match string) string {
		if e.randomBool() {
			prop := match[1:] // Убираем точку
			return fmt.Sprintf(`["%s"]`, prop)
		}
		return match
	})
}

// rotateSeed обновляет seed
func (e *Engine) rotateSeed() {
	e.currentSeed = time.Now().UnixNano() % int64(e.seedRotation)
}

// hash вычисляет хеш кода
func (e *Engine) hash(code string) string {
	h := sha256.Sum256([]byte(code))
	return hex.EncodeToString(h[:])
}

// randomBool возвращает случайный boolean
func (e *Engine) randomBool() bool {
	n, _ := rand.Int(rand.Reader, big.NewInt(2))
	return n.Int64() == 1
}

// randomInt возвращает случайное число в диапазоне [min, max)
func (e *Engine) randomInt(min, max int) int {
	if min >= max {
		return min
	}
	n, _ := rand.Int(rand.Reader, big.NewInt(int64(max-min)))
	return min + int(n.Int64())
}

// randomChoice выбирает случайный элемент из слайса
func (e *Engine) randomChoice(choices []string) string {
	if len(choices) == 0 {
		return ""
	}
	idx := e.randomInt(0, len(choices))
	return choices[idx]
}

// GetStats возвращает статистику движка
func (e *Engine) GetStats() map[string]interface{} {
	e.mu.Lock()
	defer e.mu.Unlock()
	
	return map[string]interface{}{
		"level":          e.level,
		"seed_rotation":  e.seedRotation,
		"current_seed":   e.currentSeed,
		"mutation_count": e.mutationCount,
	}
}

// Reset сбрасывает счётчик мутаций
func (e *Engine) Reset() {
	e.mu.Lock()
	defer e.mu.Unlock()
	
	e.mutationCount = 0
}
