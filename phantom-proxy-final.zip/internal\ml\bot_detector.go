package ml

import (
	"sync"
	"time"

	"go.uber.org/zap"
)

// BotDetector ML-детектор ботов (rule-based + ML через ONNX)
type BotDetector struct {
	mu        sync.RWMutex
	threshold float32
	logger    *zap.Logger
	enabled   bool
	
	// Статистика
	totalRequests   int64
	botDetections   int64
	humanDetections int64
}

// DetectionResult результат детекта
type DetectionResult struct {
	IsBot      bool               `json:"is_bot"`
	Confidence float32            `json:"confidence"`
	Features   map[string]float32 `json:"features"`
	Duration   time.Duration      `json:"duration_ms"`
}

// BotFeatures признаки для ML модели
type BotFeatures struct {
	// Временные паттерны
	RequestInterval    float32 `json:"request_interval"`
	MouseEntropy       float32 `json:"mouse_entropy"`
	KeyboardEntropy    float32 `json:"keyboard_entropy"`
	
	// TLS fingerprint
	JA3Anomaly         float32 `json:"ja3_anomaly"`
	
	// HTTP headers
	HeaderAnomaly      float32 `json:"header_anomaly"`
	UserAgentScore     float32 `json:"ua_score"`
	
	// Поведенческие
	NavigationDepth    float32 `json:"nav_depth"`
	PageStayDuration   float32 `json:"stay_duration"`
	ClickPattern       float32 `json:"click_pattern"`
	
	// Browser fingerprint
	PluginsCount       float32 `json:"plugins_count"`
	LanguagesCount     float32 `json:"languages_count"`
	WebGLVendor        float32 `json:"webgl_vendor"`
	
	// Network
	ConnectionType     float32 `json:"connection_type"`
	IPReputation       float32 `json:"ip_reputation"`
	
	// Advanced
	TouchEvents        float32 `json:"touch_events"`
	DeviceMemory       float32 `json:"device_memory"`
	HardwareConcurrency float32 `json:"hardware_concurrency"`
}

// NewRuleBasedDetector создаёт детектор на основе правил (без ML)
func NewRuleBasedDetector(logger *zap.Logger, threshold float32) *BotDetector {
	return &BotDetector{
		threshold: threshold,
		logger:    logger,
		enabled:   true,
	}
}

// Detect анализирует запрос и определяет бот/человек
func (d *BotDetector) Detect(features *BotFeatures) *DetectionResult {
	start := time.Now()
	
	d.mu.RLock()
	defer d.mu.RUnlock()
	
	d.totalRequests++
	
	result := &DetectionResult{
		Features: make(map[string]float32),
	}
	
	// Rule-based детект
	result.IsBot = d.ruleBasedDetect(features)
	result.Confidence = 0.75 // Заглушка
	result.Duration = time.Since(start)
	
	// Обновление статистики
	if result.IsBot {
		d.botDetections++
	} else {
		d.humanDetections++
	}
	
	return result
}

// ruleBasedDetect детект на основе правил
func (d *BotDetector) ruleBasedDetect(features *BotFeatures) bool {
	score := float32(0.0)
	
	// Правило 1: Слишком быстрый интервал запросов (< 100ms)
	if features.RequestInterval < 100 && features.RequestInterval > 0 {
		score += 0.3
	}
	
	// Правило 2: Аномальный JA3 fingerprint
	if features.JA3Anomaly > 0.7 {
		score += 0.25
	}
	
	// Правило 3: Подозрительные заголовки
	if features.HeaderAnomaly > 0.6 {
		score += 0.2
	}
	
	// Правило 4: Нет мыши/клавиатуры (headless)
	if features.MouseEntropy < 0.1 && features.KeyboardEntropy < 0.1 {
		score += 0.15
	}
	
	// Правило 5: Подозрительный User-Agent
	if features.UserAgentScore < 0.5 {
		score += 0.1
	}
	
	return score >= 0.5
}

// ToArray преобразует признаки в массив float32
func (f *BotFeatures) ToArray() []float32 {
	return []float32{
		f.RequestInterval,
		f.MouseEntropy,
		f.KeyboardEntropy,
		f.JA3Anomaly,
		f.HeaderAnomaly,
		f.UserAgentScore,
		f.NavigationDepth,
		f.PageStayDuration,
		f.ClickPattern,
		f.PluginsCount,
		f.LanguagesCount,
		f.WebGLVendor,
		f.ConnectionType,
		f.IPReputation,
		f.TouchEvents,
		f.DeviceMemory,
		f.HardwareConcurrency,
	}
}

// ExtractFromRequest извлекает признаки из HTTP запроса
func ExtractFromRequest(ua string, ja3Hash string, interval time.Duration) *BotFeatures {
	features := &BotFeatures{
		RequestInterval: float32(interval.Milliseconds()),
	}
	
	// Анализ User-Agent
	features.UserAgentScore = analyzeUserAgent(ua)
	
	// Анализ JA3
	features.JA3Anomaly = analyzeJA3(ja3Hash)
	
	// Default значения
	features.MouseEntropy = 0.5
	features.KeyboardEntropy = 0.5
	features.HeaderAnomaly = 0.3
	features.NavigationDepth = 5
	features.PageStayDuration = 30
	features.ClickPattern = 0.5
	features.PluginsCount = 5
	features.LanguagesCount = 2
	features.WebGLVendor = 1
	features.ConnectionType = 1
	features.IPReputation = 0.8
	features.TouchEvents = 0
	features.DeviceMemory = 8
	features.HardwareConcurrency = 8
	
	return features
}

// analyzeUserAgent анализирует User-Agent
func analyzeUserAgent(ua string) float32 {
	score := float32(1.0)
	
	// Подозрительные паттерны
	suspicious := []string{
		"curl", "wget", "python", "go-http", "bot", "spider", "crawler",
		"headless", "phantom", "selenium", "playwright", "puppeteer",
	}
	
	for _, s := range suspicious {
		if containsIgnoreCase(ua, s) {
			score -= 0.2
		}
	}
	
	// Проверка на стандартные браузеры
	browsers := []string{"Chrome", "Firefox", "Safari", "Edge"}
	hasBrowser := false
	for _, b := range browsers {
		if containsIgnoreCase(ua, b) {
			hasBrowser = true
			break
		}
	}
	
	if !hasBrowser {
		score -= 0.3
	}
	
	if score < 0 {
		score = 0
	}
	
	return score
}

// analyzeJA3 анализирует JA3 fingerprint
func analyzeJA3(ja3Hash string) float32 {
	// Пока заглушка
	// В полной версии здесь будет проверка по базе известных ботов
	if ja3Hash == "" {
		return 0.5
	}
	return 0.2
}

// containsIgnoreCase проверяет содержит ли строка подстроку (без учёта регистра)
func containsIgnoreCase(s, substr string) bool {
	return len(s) >= len(substr) && 
		(s == substr || 
		 len(s) > len(substr) && 
		 (s[:len(substr)] == substr || 
		  s[len(s)-len(substr):] == substr ||
		  containsCI(s, substr)))
}

func containsCI(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}

// GetStats возвращает статистику детектора
func (d *BotDetector) GetStats() map[string]interface{} {
	d.mu.RLock()
	defer d.mu.RUnlock()
	
	stats := map[string]interface{}{
		"enabled":          d.enabled,
		"threshold":        d.threshold,
		"total_requests":   d.totalRequests,
		"bot_detections":   d.botDetections,
		"human_detections": d.humanDetections,
	}
	
	if d.totalRequests > 0 {
		stats["bot_percentage"] = float64(d.botDetections) / float64(d.totalRequests) * 100
	}
	
	return stats
}

// UpdateThreshold обновляет порог детекта
func (d *BotDetector) UpdateThreshold(threshold float32) {
	d.mu.Lock()
	defer d.mu.Unlock()
	
	d.threshold = threshold
	d.logger.Info("Bot detector threshold updated",
		zap.Float32("threshold", threshold))
}

// Enable включает детектор
func (d *BotDetector) Enable() {
	d.mu.Lock()
	defer d.mu.Unlock()
	
	d.enabled = true
	d.logger.Info("Bot detector enabled")
}

// Disable выключает детектор
func (d *BotDetector) Disable() {
	d.mu.Lock()
	defer d.mu.Unlock()
	
	d.enabled = false
	d.logger.Info("Bot detector disabled")
}
